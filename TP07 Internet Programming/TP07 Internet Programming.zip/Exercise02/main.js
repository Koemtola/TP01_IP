//Importing the http module
const express=require("express");
const part=require("path");
const app=express();

app.use(express.static(part.join(__dirname+"/public")));

//Server listing to part 3000
app.listen((3000),()=>{
    console.log("http://localhost:3000 done!");
    console.log("Server is runnig!");
})