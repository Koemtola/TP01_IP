//Importing the http module
const express=require("express");
const part=require("path");
const app=express();

// Home 
app.use(express.static(part.join(__dirname+"/public")));

// Detail
app.get('/detail',(req,res)=>{
    res.sendFile(__dirname+"/public/detail/viewDetail.html");
});

//Server listning to part 3000
app.listen((3000),()=>{
    console.log("http://localhost:3000 done!");
    console.log("Server is runnig!");
})

/* ---------------------------------- Test ---------------------------------- */
// app.get('/',(req,res)=>{
//     res.send("Home Page");
// })
// app.get('/about',(req,res)=>{
//     res.send("Next Page");
// })