        const title=document.getElementById("title");
		const boxImg=document.getElementById("boxImg");
		const demo=document.getElementById("demo");
        const loader=document.getElementById("loading");
		main();
		function main() {
            loader.hidden=false;
			/* ---------------------------------- Data ---------------------------------- */
			const url=new URL(location);
			const id =url.searchParams.get("id");

			setTimeout(() => {
				outputData(id);
			}, 1000);
		}
		function outputData(id) {
			let baseUrl="https://jsonplaceholder.typicode.com/photos/";
			let url=`${baseUrl}${id}`;
			fetch(url).then(async(response)=>{
				loader.hidden=true;
            	let data = await response.json();
				let result="";
				result=result+`
				<div class="main">
					<div class="wrapper-one">
						<div id="title">${data.title}</div>
						<div id="id">${data.id}</div>
						<div id="text">Resize the browser window to see that this page is responsive by the way</div>
					</div>
					<div class="wrapper-two">
						<div id="id-2">${data.id}</div>
						<img id="boxImg" src="${data.thumbnailUrl}"alt=""></img>
					</div>	
				</div>	
				`
				demo.innerHTML=result;
			})
		}