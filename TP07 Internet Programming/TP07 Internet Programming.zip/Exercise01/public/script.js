const demo=document.getElementById("demo");
const nullContent=document.getElementById("null");
const loader=document.getElementById("loader");
const img=document.getElementById("img");
function main() {
    nullContent.innerHTML="";
    img.innerHTML="🔍";
    demo.innerHTML="";
    loader.hidden=false;
    fetchAPI();
}
function fetchAPI() {
    return new Promise((reslove, reject) => {
        fetch("https://www.boredapi.com/api/activity").then(async(response)=>{
            let data=await response.json();
            nullContent.innerHTML="";
            img.innerHTML="😍";
            let result="";
             // display only 50 charactor of a long string
             let str=`${data.link}`;
             if(str.length>10){
                 str=str.substring(0,20)+" ..."
             }else{
                 str=str;
             }
            if(data.link==""){
                result+=`
                <div class="wrapper-display">
                    <div id="title">${data.activity}</div>
                    <div id="type">+ Type: ${data.type}</div>
                    <div id="paricipants">+ Paricipants: ${data.participants}</div>
                    <div id="price">+ Price: ${data.price} $</div>
                    <div id="main-link">
                    <div id="link">
                        <div>+ Link: null</div>
                        <div>
                            
                        </div>
                    </div>
                    <div></div>
                </div>
                </div>
                `;
            }else{
                result+=`
                <div class="wrapper-display">
                    <div id="title">${data.activity}</div>
                    <div id="type">+ Type: ${data.type}</div>
                    <div id="paricipants">+ Paricipants: ${data.participants}</div>
                    <div id="price">+ Price: ${data.price} $</div>
                    <div id="main-link">
                        <div id="link">
                            <div>+ Link: </div>
                            <div>
                                <a href="${data.link}"> ${str}</a>
                            </div>
                        </div>
                        <div></div>
                    </div>
                </div>
                `;
            }
            demo.innerHTML=result;
            loader.hidden=true;
        })
    });
}